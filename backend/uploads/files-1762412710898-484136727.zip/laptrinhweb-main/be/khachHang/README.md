<h1 align="center"> Khách hàng Xem menu và Đặt hàng </h1>



# Luồng thực hiện
## CSDL `quan_an_db2024`:

## Luồng thực hiện

### Hiển thị DS các món ăn trong CSDL (Những món được hiển thị) & tìm kiếm, phân loại món ăn

![Luồng thực hiện](../../assets/img-luong-thuc-hien/khachHang-Xem-Timkiem_mon_tr_menu.jpg "Luồng thực hiện cho việc hiển thị và tìm kiếm món ăn")

### Thêm món ăn vào Giỏ hàng

![Luồng thực hiện](../../assets/img-luong-thuc-hien/khachHang-ThemMonAnVaoGioHang.jpg "Luồng thực hiện cho việc Thêm món ăn vào giỏ hàng")


### Xem và Sửa giỏ hàng (sửa số lượng món)

<!-- ![Luồng thực hiện](../../assets/img-luong-thuc-hien/chuQuan-SuaMonAn.jpg "Luồng thực hiện cho việc Sửa món ăn") -->

### Xóa món ăn trong giỏ hàng

<!-- ![Luồng thực hiện](../../assets/img-luong-thuc-hien/chuQuan-XoaMonAn.jpg "Luồng thực hiện cho việc Xóa món ăn") -->


### Đặt hàng



