# Nguồn ảnh
- Hầu hết các ảnh đều được tải miễn phí từ nền tảng Pinterest sau đó được tách nền tại: https://www.remove.bg/upload
- Các hình ảnh đều chưa được xin bản quyền chính thức. Nếu được yêu cầu người thực hiện sẽ xóa ảnh và chịu mọi trách nhiệm liên quan.

#